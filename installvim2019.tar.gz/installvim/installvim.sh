#!/bin/bash
sudo apt-get install ctags cscope wget unzip -y
sudo apt-get install astyle
sudo tar -xvf master.tar.gz
sudo cp -rf vim-ide-master/.vim* ~
sudo rm -rf ./vim-ide-master 
cp .vimrc ../
